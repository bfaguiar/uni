/**
 * Calculadora com fracções - Versão 1:
 * Programa monolítico.
 * <P>
 * Exemplo de uma calculadora simples que trabalha com fracções.
 * Nesta versão, o programa está implementado num única função no ficheiro
 * {@link v1.FractionCalculator FractionCalculator.java}.
 */
package v1;

